// TradingViewWidget.jsx
import React, { useEffect, useRef, memo } from 'react';

function AssetGrapg({symbol}) {
  const container = useRef();

  useEffect(
    () => {
      const script = document.createElement("script");
      script.src = "https://s3.tradingview.com/external-embedding/embed-widget-symbol-overview.js";
      script.type = "text/javascript";
      script.async = true;
      if (symbol == "HP"){
        script.innerHTML = `
        {
          "symbols": [
            [
              "NYSE:HP|1D"
            ]
          ],
          "chartOnly": false,
          "width": "100%",
          "height": "100%",
          "locale": "in",
          "colorTheme": "dark",
          "autosize": true,
          "showVolume": false,
          "showMA": false,
          "hideDateRanges": false,
          "hideMarketStatus": false,
          "hideSymbolLogo": false,
          "scalePosition": "no",
          "scaleMode": "Normal",
          "fontFamily": "-apple-system, BlinkMacSystemFont, Trebuchet MS, Roboto, Ubuntu, sans-serif",
          "fontSize": "10",
          "noTimeScale": false,
          "valuesTracking": "1",
          "changeMode": "percent-only",
          "chartType": "area",
          "maLineColor": "#2962FF",
          "maLineWidth": 1,
          "maLength": 9,
          "backgroundColor": "rgba(19, 23, 34, 0)",
          "lineWidth": 2,
          "lineType": 2,
          "dateRanges": [
            "1d|1",
            "1m|30",
            "3m|60",
            "12m|1D",
            "60m|1W",
            "all|1M"
          ],
          "lineColor": "rgba(255, 235, 59, 1)",
          "topColor": "rgba(251, 192, 45, 0.43)",
          "bottomColor": "rgba(255, 238, 88, 0.33)",
          "timeHoursFormat": "12-hours"
        }`;
        container.current.appendChild(script);
      }
      if (symbol == "AAPL"){
        script.innerHTML = `
        {
          "symbols": [
            [
              "AAPL|1D"
            ]
          ],
          "chartOnly": false,
          "width": "100%",
          "height": "100%",
          "locale": "in",
          "colorTheme": "dark",
          "autosize": true,
          "showVolume": false,
          "showMA": false,
          "hideDateRanges": false,
          "hideMarketStatus": false,
          "hideSymbolLogo": false,
          "scalePosition": "no",
          "scaleMode": "Normal",
          "fontFamily": "-apple-system, BlinkMacSystemFont, Trebuchet MS, Roboto, Ubuntu, sans-serif",
          "fontSize": "10",
          "noTimeScale": false,
          "valuesTracking": "1",
          "changeMode": "percent-only",
          "chartType": "area",
          "maLineColor": "#2962FF",
          "maLineWidth": 1,
          "maLength": 9,
          "backgroundColor": "rgba(19, 23, 34, 0)",
          "lineWidth": 2,
          "lineType": 2,
          "dateRanges": [
            "1d|1",
            "1m|30",
            "3m|60",
            "12m|1D",
            "60m|1W",
            "all|1M"
          ],
          "lineColor": "rgba(255, 235, 59, 1)",
          "topColor": "rgba(251, 192, 45, 0.43)",
          "bottomColor": "rgba(255, 238, 88, 0.33)",
          "timeHoursFormat": "12-hours"
        }`;
        container.current.appendChild(script);
      }
      if (symbol == "GOOGL"){
        script.innerHTML = `
        {
          "symbols": [
            [
              "GOOGL|1D"
            ]
          ],
          "chartOnly": false,
          "width": "100%",
          "height": "100%",
          "locale": "in",
          "colorTheme": "dark",
          "autosize": true,
          "showVolume": false,
          "showMA": false,
          "hideDateRanges": false,
          "hideMarketStatus": false,
          "hideSymbolLogo": false,
          "scalePosition": "no",
          "scaleMode": "Normal",
          "fontFamily": "-apple-system, BlinkMacSystemFont, Trebuchet MS, Roboto, Ubuntu, sans-serif",
          "fontSize": "10",
          "noTimeScale": false,
          "valuesTracking": "1",
          "changeMode": "percent-only",
          "chartType": "area",
          "maLineColor": "#2962FF",
          "maLineWidth": 1,
          "maLength": 9,
          "backgroundColor": "rgba(19, 23, 34, 0)",
          "lineWidth": 2,
          "lineType": 2,
          "dateRanges": [
            "1d|1",
            "1m|30",
            "3m|60",
            "12m|1D",
            "60m|1W",
            "all|1M"
          ],
          "lineColor": "rgba(255, 235, 59, 1)",
          "topColor": "rgba(251, 192, 45, 0.43)",
          "bottomColor": "rgba(255, 238, 88, 0.33)",
          "timeHoursFormat": "12-hours"
        }`;
        container.current.appendChild(script);
      }
      if (symbol == "MSFT"){
        script.innerHTML = `
        {
          "symbols": [
            [
              "MSFT|1D"
            ]
          ],
          "chartOnly": false,
          "width": "100%",
          "height": "100%",
          "locale": "in",
          "colorTheme": "dark",
          "autosize": true,
          "showVolume": false,
          "showMA": false,
          "hideDateRanges": false,
          "hideMarketStatus": false,
          "hideSymbolLogo": false,
          "scalePosition": "no",
          "scaleMode": "Normal",
          "fontFamily": "-apple-system, BlinkMacSystemFont, Trebuchet MS, Roboto, Ubuntu, sans-serif",
          "fontSize": "10",
          "noTimeScale": false,
          "valuesTracking": "1",
          "changeMode": "percent-only",
          "chartType": "area",
          "maLineColor": "#2962FF",
          "maLineWidth": 1,
          "maLength": 9,
          "backgroundColor": "rgba(19, 23, 34, 0)",
          "lineWidth": 2,
          "lineType": 2,
          "dateRanges": [
            "1d|1",
            "1m|30",
            "3m|60",
            "12m|1D",
            "60m|1W",
            "all|1M"
          ],
          "lineColor": "rgba(255, 235, 59, 1)",
          "topColor": "rgba(251, 192, 45, 0.43)",
          "bottomColor": "rgba(255, 238, 88, 0.33)",
          "timeHoursFormat": "12-hours"
        }`;
        container.current.appendChild(script);
      }
      if (symbol == "TSLA"){
        script.innerHTML = `
        {
          "symbols": [
            [
              "NASDAQ:TSLA|1D"
            ]
          ],
          "chartOnly": false,
          "width": "100%",
          "height": "100%",
          "locale": "in",
          "colorTheme": "dark",
          "autosize": true,
          "showVolume": false,
          "showMA": false,
          "hideDateRanges": false,
          "hideMarketStatus": false,
          "hideSymbolLogo": false,
          "scalePosition": "no",
          "scaleMode": "Normal",
          "fontFamily": "-apple-system, BlinkMacSystemFont, Trebuchet MS, Roboto, Ubuntu, sans-serif",
          "fontSize": "10",
          "noTimeScale": false,
          "valuesTracking": "1",
          "changeMode": "percent-only",
          "chartType": "area",
          "maLineColor": "#2962FF",
          "maLineWidth": 1,
          "maLength": 9,
          "backgroundColor": "rgba(19, 23, 34, 0)",
          "lineWidth": 2,
          "lineType": 2,
          "dateRanges": [
            "1d|1",
            "1m|30",
            "3m|60",
            "12m|1D",
            "60m|1W",
            "all|1M"
          ],
          "lineColor": "rgba(255, 235, 59, 1)",
          "topColor": "rgba(251, 192, 45, 0.43)",
          "bottomColor": "rgba(255, 238, 88, 0.33)",
          "timeHoursFormat": "12-hours"
        }`;
        container.current.appendChild(script);
      }
      if (symbol == "META"){
        script.innerHTML = `
        {
          "symbols": [
            [
              "NASDAQ:META|1D"
            ]
          ],
          "chartOnly": false,
          "width": "100%",
          "height": "100%",
          "locale": "in",
          "colorTheme": "dark",
          "autosize": true,
          "showVolume": false,
          "showMA": false,
          "hideDateRanges": false,
          "hideMarketStatus": false,
          "hideSymbolLogo": false,
          "scalePosition": "no",
          "scaleMode": "Normal",
          "fontFamily": "-apple-system, BlinkMacSystemFont, Trebuchet MS, Roboto, Ubuntu, sans-serif",
          "fontSize": "10",
          "noTimeScale": false,
          "valuesTracking": "1",
          "changeMode": "percent-only",
          "chartType": "area",
          "maLineColor": "#2962FF",
          "maLineWidth": 1,
          "maLength": 9,
          "backgroundColor": "rgba(19, 23, 34, 0)",
          "lineWidth": 2,
          "lineType": 2,
          "dateRanges": [
            "1d|1",
            "1m|30",
            "3m|60",
            "12m|1D",
            "60m|1W",
            "all|1M"
          ],
          "lineColor": "rgba(255, 235, 59, 1)",
          "topColor": "rgba(251, 192, 45, 0.43)",
          "bottomColor": "rgba(255, 238, 88, 0.33)",
          "timeHoursFormat": "12-hours"
        }`;
        container.current.appendChild(script);
      }
      if (symbol == "NFLX"){
        script.innerHTML = `
        {
          "symbols": [
            [
              "NASDAQ:NFLX|1D"
            ]
          ],
          "chartOnly": false,
          "width": "100%",
          "height": "100%",
          "locale": "in",
          "colorTheme": "dark",
          "autosize": true,
          "showVolume": false,
          "showMA": false,
          "hideDateRanges": false,
          "hideMarketStatus": false,
          "hideSymbolLogo": false,
          "scalePosition": "no",
          "scaleMode": "Normal",
          "fontFamily": "-apple-system, BlinkMacSystemFont, Trebuchet MS, Roboto, Ubuntu, sans-serif",
          "fontSize": "10",
          "noTimeScale": false,
          "valuesTracking": "1",
          "changeMode": "percent-only",
          "chartType": "area",
          "maLineColor": "#2962FF",
          "maLineWidth": 1,
          "maLength": 9,
          "backgroundColor": "rgba(19, 23, 34, 0)",
          "lineWidth": 2,
          "lineType": 2,
          "dateRanges": [
            "1d|1",
            "1m|30",
            "3m|60",
            "12m|1D",
            "60m|1W",
            "all|1M"
          ],
          "lineColor": "rgba(255, 235, 59, 1)",
          "topColor": "rgba(251, 192, 45, 0.43)",
          "bottomColor": "rgba(255, 238, 88, 0.33)",
          "timeHoursFormat": "12-hours"
        }`;
        container.current.appendChild(script);
      }
      if (symbol == "DELL"){
        script.innerHTML = `
        {
          "symbols": [
            [
              "NYSE:DELL|1D"
            ]
          ],
          "chartOnly": false,
          "width": "100%",
          "height": "100%",
          "locale": "in",
          "colorTheme": "dark",
          "autosize": true,
          "showVolume": false,
          "showMA": false,
          "hideDateRanges": false,
          "hideMarketStatus": false,
          "hideSymbolLogo": false,
          "scalePosition": "no",
          "scaleMode": "Normal",
          "fontFamily": "-apple-system, BlinkMacSystemFont, Trebuchet MS, Roboto, Ubuntu, sans-serif",
          "fontSize": "10",
          "noTimeScale": false,
          "valuesTracking": "1",
          "changeMode": "percent-only",
          "chartType": "area",
          "maLineColor": "#2962FF",
          "maLineWidth": 1,
          "maLength": 9,
          "backgroundColor": "rgba(19, 23, 34, 0)",
          "lineWidth": 2,
          "lineType": 2,
          "dateRanges": [
            "1d|1",
            "1m|30",
            "3m|60",
            "12m|1D",
            "60m|1W",
            "all|1M"
          ],
          "lineColor": "rgba(255, 235, 59, 1)",
          "topColor": "rgba(251, 192, 45, 0.43)",
          "bottomColor": "rgba(255, 238, 88, 0.33)",
          "timeHoursFormat": "12-hours"
        }`;
        container.current.appendChild(script);
      }
  

      // script.innerHTML = `
      //   {
      //     "symbols": [
      //       [
      //         "NYSE:HP|1D"
      //       ]
      //     ],
      //     "chartOnly": false,
      //     "width": "100%",
      //     "height": "100%",
      //     "locale": "in",
      //     "colorTheme": "dark",
      //     "autosize": true,
      //     "showVolume": false,
      //     "showMA": false,
      //     "hideDateRanges": false,
      //     "hideMarketStatus": false,
      //     "hideSymbolLogo": false,
      //     "scalePosition": "no",
      //     "scaleMode": "Normal",
      //     "fontFamily": "-apple-system, BlinkMacSystemFont, Trebuchet MS, Roboto, Ubuntu, sans-serif",
      //     "fontSize": "10",
      //     "noTimeScale": false,
      //     "valuesTracking": "1",
      //     "changeMode": "percent-only",
      //     "chartType": "area",
      //     "maLineColor": "#2962FF",
      //     "maLineWidth": 1,
      //     "maLength": 9,
      //     "backgroundColor": "rgba(19, 23, 34, 0)",
      //     "lineWidth": 2,
      //     "lineType": 2,
      //     "dateRanges": [
      //       "1d|1",
      //       "1m|30",
      //       "3m|60",
      //       "12m|1D",
      //       "60m|1W",
      //       "all|1M"
      //     ],
      //     "lineColor": "rgba(255, 235, 59, 1)",
      //     "topColor": "rgba(251, 192, 45, 0.43)",
      //     "bottomColor": "rgba(255, 238, 88, 0.33)",
      //     "timeHoursFormat": "12-hours"
      //   }`;

      
    },
    []
  );

  return (
    <div className="tradingview-widget-container" ref={container}>
      <div className="tradingview-widget-container__widget"></div>
      <div className="tradingview-widget-copyright"><a href="https://in.tradingview.com/" rel="noopener nofollow" target="_blank"><span className="blue-text"></span></a></div>
    </div>
  );
}

export default memo(AssetGrapg);
