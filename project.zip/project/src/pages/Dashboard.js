import React, { useState } from 'react'
import mounntain from "./mountain.png"
const Dashboard = ({handleAssetClickaz }) => {

    const [assets, set_assets]= useState( [
        {
            sno: 1,
            name: "Apple",
            symbol: "AAPL"
        },
        {
            sno: 2,
            name: "Google",
            symbol: "GOOGL"
        },
        {
            sno: 3,
            name: "Microsoft",
            symbol: "MSFT"
        },
        {
            sno: 4,
            name: "Tesla",
            symbol: "TSLA"
        },
        {
            sno: 5,
            name: "Meta",
            symbol: "META"
        },
        {
            sno: 6,
            name: "NetFlix",
            symbol: "NFLX"
        },
        {
            sno: 7,
            name: "Dell",
            symbol: "DELL"
        },
        {
            sno: 8,
            name: "HP",
            symbol: "HP"
        },
    ] )
  
    const handleAssetClick= (asset) => {
        handleAssetClickaz(asset);
    }

  return (
    <div className='flex flex-col gap-9 flex-grow w-screen w-full'>
      <div className='flex px-[100px] pt-[100px] h-screen'>
        <h1 className='text-[#e7e752] text-[100px] font-black'>
            Avalanche <br/> Trade
        </h1>
        <div className='w-1/2'>  
            <img
                className='w-full'
                src= {mounntain}
                />
        </div>
      </div>
      <div className=' h-screen px-[100px]'>
        <div className='bg-gradient-to-b from-[#25262b] to-[#1b1c21] flex items-center py-[100px] rounded-3xl flex-col gap-[50px] '>
            <h1 className='text-white font-black text-3xl'>The Way You Trade</h1>
            <div className='flex flex-col gap-5 text-white w-full  px-[340px] '>
                {
                    assets.map (asset => {
                        return (
                            <div className='flex cursor-pointer rounded-3xl hover:bg-[#141519] ' onClick= {() => handleAssetClick(asset.symbol)}>
                                <h1 className='w-[100px] p-5 pl-9 '> {asset.sno} </h1>
                                <h1 className='w-[300px] p-5 '> {asset.symbol} </h1>
                                <h1 className='w-[100px] p-5 '> {asset.name} </h1>
                            </div>
                        )
                    })
                }
            </div>
        </div>
      </div>
    </div>
  )
}

export default Dashboard
