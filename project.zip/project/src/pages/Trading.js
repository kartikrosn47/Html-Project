import React, { useState } from 'react'
import AssetGrapg from '../components/AssetGrapg'

const Trading = ({symbol}) => {

    const [buySelected, set_buySelected]= useState(true);

    const toggleButton = (click) => {
        click == "buy" && set_buySelected(true);
        click == "sell" && set_buySelected(false);
    }
    
  return (
    <div className='flex gap-4 flex-grow w-full'>
        <div className='w-[75%] h-full bg-gradient-to-b from-[#25262b] to-[#1b1c21]   '>
            <AssetGrapg
                symbol= {symbol}
                className= "w-full"
            />
        </div>
        <div className='w-[25%] h-full bg-[#e7e752] rounded-xl px-4 flex flex-col gap-9 py-9 justify-between'>
            <div className= "flex flex-col gap-9"> 
            <h1 className='text-3xl'>
                Make a Trade
            </h1>
            <div className='flex border-2 border-[#9e9e55] w-full rounded-3xl'>
                <button
                    onClick= {() => toggleButton("buy")}
                    className={buySelected ? 'w-1/2  bg-none border-2 border-black rounded-3xl p-3 font-semibold ': 'w-1/2  bg-none border-2 border-none rounded-3xl p-3 font-semibold '}>
                    BUY
                </button>
                <button
                    onClick= {() => toggleButton("sell")}
                    className={!buySelected ? 'w-1/2  bg-none border-2 border-black rounded-3xl p-3 font-semibold ': 'w-1/2  bg-none border-2 border-none rounded-3xl p-3 font-semibold '}>
                    SELL
                </button>
            </div>
            <div>
                    <p className='pb-6'> You give:</p>
                    <input
                        type= "text"
                        className='w-full p-3 border-2 border-[#9e9e55] rounded-xl bg-transparent'
                        />
                </div>
                <div>
                    <p className='pb-6'> You give:</p>
                    <div className='flex gap-4 items-center border-2 border-[#9e9e55] rounded-xl'>  
                    <p className='pl-6 font-bold text-xl '>$</p>
                    <input
                        type= "text"
                        className='w-full p-3 border-none bg-transparent'
                        />
                        <p className='pr-6 font-bold text-xl '>USD</p>
                         </div>
                </div>
               
                </div>
                <button className='w-full rounded-3xl bg-black text-white p-3 font-bold text-xl'>Submit</button>
        </div>
    </div>
  )
}

export default Trading
