import {useState} from "react"
import Dashboard from "./pages/Dashboard"
import Trading from "./pages/Trading"

function App() {
  const [btnStats, set_btnStats]= useState({
    dashboard: {
      show: true
    },
    trading: {
      show: false
    }
  })
  const [currentSymbol, set_currrentSymbol]= useState("AAPL")

  const handleBtnClick = (btnName) => {
    btnName == "dashBtn" && set_btnStats({
      dashboard: {
        show: true
      },
      trading: {
        show: false
      }
    })
    btnName == "tradeBtn" && set_btnStats({
      dashboard: {
        show: false
      },
      trading: {
        show: true
      }
    })
  }

  const handleAssetClick = (asset) => {
    set_currrentSymbol(asset);
    set_btnStats({
      dashboard: {
        show: false
      },
      trading: {
        show: true
      }
    })
  }

  return (
    <div className="flex flex-col gap-[100px] px-4 py-2 h-screen">
      <div className= "flex justify-between">
        <h1 className= "text-white">Avalanche Trade</h1>
        <div className= "flex gap-4">
          <button className= {btnStats.dashboard.show ? " text-black px-4  font-bold bg-[#e7e752]  rounded-xl"  : " text-white px-4  font-bold bg-none  rounded-xl"} onClick={ () => handleBtnClick("dashBtn") } > Dashboard </button>
          <button className= {btnStats.trading.show ? " text-black px-4  font-bold bg-[#e7e752]  rounded-xl"  : " text-white px-4  font-bold bg-none  rounded-xl"} onClick={ () => handleBtnClick("tradeBtn") } > Trading </button>
        </div>
        <div></div>
      </div>
      {btnStats.dashboard.show && <Dashboard handleAssetClickaz= {handleAssetClick}/> }
      {btnStats.trading.show &&  <Trading symbol={currentSymbol} /> }
    </div>
  );
}

export default App;
